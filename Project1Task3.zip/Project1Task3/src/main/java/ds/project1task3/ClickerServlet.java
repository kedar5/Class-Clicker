package ds.project1task3;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@WebServlet(name ="ClickerServlet", urlPatterns = {"/submit","/ClickerServlet","/getResults"})
public class ClickerServlet extends HttpServlet {

    ClickerModel cm = null;
    @Override
    public void init() {
        cm = new ClickerModel();
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String answer = request.getParameter("answer");
        String ua = request.getHeader("User-Agent");
        System.out.println("Ans in request: "+answer);
        System.out.println("va: "+ ua);
        String nextView;
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        Map<String,Integer> counter = cm.storeValue(answer);
        String uri = request.getRequestURI();
        System.out.println("URI : "+uri);
        if (uri.equalsIgnoreCase("/Project1Task3-1.0-SNAPSHOT/getResults")){

            if (cm.getflag()){
                System.out.println("No value yet");
                request.setAttribute("zeroflag", cm.getflag());
            }
            else{
                Map<String, Integer> finalmap =cm.getValue();
                List l1=new ArrayList(finalmap.keySet());
                for(int i=0;i< l1.size();i++){

                }
                request.setAttribute("finalmap", finalmap);
            }

            nextView = "results.jsp";
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }
        else{
            if (answer != null) {
                request.setAttribute("answer",answer);
                request.setAttribute("counter",counter);
                nextView = "submit.jsp";
            } else {
                // no search parameter so choose the prompt view
                nextView = "index.jsp";
            }
            // Transfer control over to the correct "view"
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
