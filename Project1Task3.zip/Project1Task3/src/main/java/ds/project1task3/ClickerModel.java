package ds.project1task3;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;

public class ClickerModel {

    //List<Integer> counter = new ArrayList<Integer>(Collections.nCopies(4, 0));
    Map<String, Integer> countermap = new HashMap() {{
        put("A", 0);
        put("B", 0);
        put("C", 0);
        put("D", 0);
    }};


    public Map<String,Integer> storeValue(String answer)
            throws UnsupportedEncodingException {
        /*
         * URL encode the searchTag, e.g. to encode spaces as %20
         *
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */


        if (answer != null){
            answer = URLEncoder.encode(answer, "UTF-8");
            if (answer.equalsIgnoreCase("A")){

                int last = countermap.get("A");
                countermap.replace("A",last,last+1);
            }
            else if (answer.equalsIgnoreCase("B")){

                int last = countermap.get("B");
                countermap.replace("B",last,last+1);
            }
            else if (answer.equalsIgnoreCase("C")){
                int last = countermap.get("C");
                countermap.replace("C",last,last+1);

            }
            else if(answer.equalsIgnoreCase("D")){
                int last = countermap.get("D");
                countermap.replace("D",last,last+1);
            }
            else{
                System.out.println("Null value "+answer);
            }
            System.out.println("value passed "+countermap);
            return countermap;
        }
        else{
            System.out.println("null passed "+ countermap);
            return countermap;

        }


    }

    public Map<String, Integer> getValue() throws  UnsupportedEncodingException{
        System.out.println("before "+ countermap);
        //countermap.values().removeIf(f -> f == 0f);
        // Removing all zero values
        countermap.values().removeAll(Collections.singleton(0));
        System.out.println("After "+countermap);
        //Sorting in Alphabetical order
        List sortedkeys=new ArrayList(countermap.keySet());
        Collections.sort(sortedkeys);

        Map <String, Integer> finalmap = new HashMap<>();
        for (int i=0;i< sortedkeys.size(); i++){
            countermap.get(sortedkeys.get(i));
            finalmap.put(sortedkeys.get(i).toString(),countermap.get(sortedkeys.get(i)));
        }
        System.out.println("final "+finalmap);
        return finalmap;
    }
    public boolean getflag(){
        boolean zeroflag = false;
        System.out.println("iNSIDE GETFLAG"+countermap);
        System.out.println(countermap.get("A"));
        System.out.println(countermap.get("B"));
        System.out.println(countermap.get("C"));
        System.out.println(countermap.get("D"));
        if (countermap.get("A")==0 & countermap.get("B")==0 & countermap.get("C")==0 & countermap.get("D")==0){
            zeroflag =true;
        }
        return zeroflag;
    }
}